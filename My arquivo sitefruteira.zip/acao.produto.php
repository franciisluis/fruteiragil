<?php
	require_once('inc.conect.php');
	(isset($_POST['nome_produto'])) and !empty($_POST['nome_produto']) 	? $nome= $_POST['nome_produto'] 	: $erro = TRUE; 
	(isset($_POST['qtd_produto'])) 	and !empty($_POST['qtd_produto']) 	? $qtd= $_POST['qtd_produto'] 		: $erro = TRUE;  
	(isset($_POST['valor_produto']))and !empty($_POST['valor_produto']) ? $valor= $_POST['valor_produto'] 	: $erro = TRUE;
	(isset($_POST['categoria'])) 	and !empty($_POST['categoria']) 	? $categoria= $_POST['categoria'] 	: $erro = TRUE;
	(isset($_REQUEST['acao'])) 		and !empty($_REQUEST['acao']) 		? $acao= $_REQUEST['acao'] 			: $erro = TRUE;
		

	switch ($acao) {
		case 'insert':
			echo 'Inserir registro';
			$query = 'INSERT INTO produto(nome_produto,qtd_produto,valor_produto,id_categoria) VALUES("'.$nome.'","'.$quantidade.'","'.$valor.'","'.$categoria.'")';

			mysql_query($query,$link) or die(mysql_error());
			$msg=1;
			break;

		case 'update':
			(isset($_POST['id_produto']) and !empty($_POST['id_produto'])) ? $id_produto = $_POST['id_produto'] : $erro = TRUE;

			$query = 'UPDATE produto SET nome_produto = "'.$nome.'",qtd_produto="'.$qtd.'",valor_produto="'.$valor.'",id_categoria="'.$categoria.'" WHERE id_produto = '.$id_produto;

			mysql_query($query, $link) or die(mysql_error());

			$msg=3;

			break;

		case 'delete':
			(isset($_GET['id_produto'])) and !empty($_GET['id_produto']) ? $id_produto= $_GET['id_produto'] 	: $erro = TRUE; 

			$query= 'DELETE FROM produto WHERE id_produto = '.$id_produto;

			mysql_query($query,$link) or die(mysql_error());
			$msg=2;
			break;
		default:
			break;
	}
	mysql_close();
	header("Location:index.php?pg=produto&msg=".$msg."");

	exit;

?>