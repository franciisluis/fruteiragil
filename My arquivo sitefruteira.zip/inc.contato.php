<form>
	<div class="container">
		<table class="table table-condensed table-striped table-bordered table-hover">
			<tr>
				<td align="center"> TELEFONE: </td>
				<td align="center"> 51999832004 </td>
			</tr>
			<td align="center"> ENDEREÇO: </td>
			<td align="center"> Vânius Abílio dos santos 1109</td>
			<tr>
				<td align="center"> E-MAIL: </td>
				<td align="center"> contato@fruteiradagil.com.br </td>
			</tr>
		</table>
	</div>
</form>