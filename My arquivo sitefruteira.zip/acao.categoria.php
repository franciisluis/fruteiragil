<?php
	require_once('inc.conect.php');
	(isset($_POST['nome_categoria'])) 	and !empty($_POST['nome_categoria']) 		? $nome = $_POST['nome_categoria'] 		: $erro = TRUE;
	(isset($_REQUEST['acao'])) 	and !empty($_REQUEST['acao']) 		? $acao= $_REQUEST['acao'] 		: $erro = TRUE;


	switch ($acao) {
		case 'insert':
			echo 'Inserir registro';
			$query = 'INSERT INTO categoria(nome_categoria) VALUES("'.$nome.'")';
			
			mysql_query($query,$link) or die(mysql_error());
			$msg=1;
			break;

		case 'update':
			(isset($_POST['id_categoria']) and !empty($_POST['id_categoria'])) ? $id_categoria = $_POST['id_categoria'] : $erro = TRUE;

			$query = 'UPDATE categoria SET nome_categoria = "'.$nome.'" WHERE id_categoria = '.$id_categoria;

			mysql_query($query, $link) or die(mysql_error());

			$msg=3;

			break;

		case 'delete':
			(isset($_GET['id_categoria'])) and !empty($_GET['id_categoria']) ? $id_categoria= $_GET['id_categoria'] : $erro = TRUE; 
			$query= 'DELETE FROM categoria WHERE id_categoria = '.$id_categoria;

			mysql_query($query,$link) or die (mysql_error());
			$msg=2;
			break;

		default:
			break;
	}
	mysql_close();
	header("Location:index.php?pg=cadastro_categoria&msg=".$msg."");

	exit;

?>