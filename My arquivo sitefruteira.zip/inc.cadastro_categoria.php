<form action = "acao.categoria.php" method="POST">
	<div class="container">
	<table class="table table-condensed table-striped table-bordered table-hover">
		<input type="hidden" name="acao" value="insert">
		<?php
				if((isset($_GET['id_categoria'])) and !empty($_GET['id_categoria'])){
					$id_categoria =  $_GET['id_categoria'];
					$query = 'SELECT * FROM categoria WHERE id_categoria='.$id_categoria;
					$retorno = mysql_query($query,$link);
					if(mysql_num_rows($retorno)>0){
						$linha=mysql_fetch_assoc($retorno);
						$nome=$linha['nome_categoria'];
						$acao="update";
					}else{
						$nome="";
						$acao="insert";
					}
				}else{
						$nome="";
						$acao="insert";
				}
		?>
		<!--<form action="acao.cadastrarcategoria.php" method="POST">-->
	
		<?php
			if ($acao == 'update') {
				echo '<input type="hidden" name="id_categoria" value="'.$id_categoria.'">';
				echo '<input type="hidden" name="acao" value="update">';
			} else {
				echo '<input type="hidden" name="acao" value="insert">';	
			}
		?>
	
		<tr>
			<td colspan="2" align="center">CADASTRAR CATEGORIA</td>
		</tr>
		<tr>
			<td align="center">NOME</td>
			<?php
				echo '<td align="center"><input type="text" name="nome_categoria" value=" '.$nome.'"</td>';
			?>
		</tr>
		<tr>
			<td colspan="2" align="center"><input type="submit" name="botao" value="ENVIAR"></td>
		</tr>
	</table>
</div>

</form>
<div class="container">
	<h2> Lista Categoria</h2>
		<table class="table table-condensed table-striped table-bordered table-hover">

		<tr>

			<td> ID </td>
			<td> Nome </td>
			<td> Acao </td>
		</tr>

		<?php
			$query = 'SELECT id_categoria, nome_categoria FROM categoria ORDER BY nome_categoria';

			$res = mysql_query($query,$link);
			//echo $res;

			$qtd=mysql_num_rows($res); //numero de linhas
			//echo $qtd;

			if($qtd>0){
				while($linha=mysql_fetch_assoc($res)){
					echo '<tr>';
					echo '<td>'. $linha['id_categoria'].'</td>';
					echo '<td>'. $linha['nome_categoria'].'</td>';

					echo '<td>
							<a href="index.php?pg=cadastro_categoria&id_categoria='.$linha['id_categoria'].'"> Editar </a> ||
							<a href="acao.categoria.php?acao=delete&id_categoria='.$linha['id_categoria'].'"> Excluir </a>
							</td>';
				}

			}else{

				echo '<tr>
						<td collspan="3" > Nenhum registro para listrar </td>
					</tr>';

			}	
	?>

	</table> 