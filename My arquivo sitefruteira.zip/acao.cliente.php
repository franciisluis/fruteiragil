<?php
	require_once('inc.conect.php');


	(isset($_POST['nome_cliente'])) and !empty($_POST['nome_cliente']) 	? $nome= $_POST['nome_cliente'] 	: $erro = TRUE; 
	(isset($_POST['telefone'])) 	and !empty($_POST['telefone']) 		? $telefone= $_POST['telefone'] 	: $erro = TRUE;  
	(isset($_POST['endereco'])) 	and !empty($_POST['endereco']) 		? $endereco= $_POST['endereco'] 	: $erro = TRUE;  
	(isset($_POST['email'])) 		and !empty($_POST['email']) 		? $email= $_POST['email'] 			: $erro = TRUE;
	(isset($_POST['cpf'])) 			and !empty($_POST['cpf']) 			? $cpf= $_POST['cpf'] 				: $erro = TRUE;
	(isset($_REQUEST['acao'])) 		and !empty($_REQUEST['acao']) 		? $acao= $_REQUEST['acao'] 			: $erro = TRUE;
	

	switch ($acao) {
		case 'insert':
			echo 'Inserir registro';
			$query = 'INSERT INTO cliente(nome_cliente,email,telefone,endereco,cpf) VALUES("'.$nome.'","'.$email.'","'.$telefone.'","'.$endereco.'","'.$cpf.'")';
		
			mysql_query($query,$link) or die(mysql_error());

			$msg=1;
			break;

		case 'update':
			(isset($_POST['id_cliente']) and !empty($_POST['id_cliente'])) ? $id_cliente = $_POST['id_cliente'] : $erro = TRUE;

			$query = 'UPDATE cliente SET nome_cliente= "'.$nome.'", telefone="'.$telefone.'", endereco="'.$endereco.'", email="'.$email.'", cpf="'.$cpf.'" WHERE id_cliente = '.$id_cliente;

			mysql_query($query, $link) or die(mysql_error());

			$msg=3;

			break;

		case 'delete':
			(isset($_GET['id_cliente'])) and !empty($_GET['id_cliente']) ? $id_cliente= $_GET['id_cliente'] 	: $erro = TRUE; 

			$query= 'DELETE FROM cliente WHERE id_cliente = '.$id_cliente;

			mysql_query($query,$link) or die (mysql_error());
			$msg=2;
	
			break;

		default:
			break;
	}
	mysql_close();
	header("Location:index.php?pg=cadastro_cliente&msg=".$msg."");

	exit;

?>