<form action = "acao.cliente.php" method="POST">
	<div class="container">
		<table class="table table-condensed table-striped table-bordered table-hover">
			<input type="hidden" name="acao" value="insert">
				<?php
					if((isset($_GET['id_cliente'])) and !empty($_GET['id_cliente'])){
						$id_cliente =  $_GET['id_cliente'];
						$query = 'SELECT * FROM cliente WHERE id_cliente='.$id_cliente;
						$retorno = mysql_query($query,$link);
						if(mysql_num_rows($retorno)>0){
							$linha=mysql_fetch_assoc($retorno);
							$nome=$linha['nome_cliente'];
							$telefone=$linha['telefone'];
							$endereco=$linha['endereco'];
							$email=$linha['email'];
							$cpf=$linha['cpf'];
							$acao="update";
						}else{
							$nome="";
							$telefone="";
							$endereco="";
							$email="";
							$cpf="";
							$acao="insert";
						}
					}else{
						$nome="";
						$telefone="";
						$endereco="";
						$email="";
						$cpf="";
						$acao="insert";
					}
				?>


				<?php
					if ($acao == 'update') {
						echo '<input type="hidden" name="id_cliente" value="'.$id_cliente.'">';
						echo '<input type="hidden" name="acao" value="update">';
					} else {
						echo '<input type="hidden" name="acao" value="insert">';	
					}
				?>
			<tr>
				<td align="center"> NOME: </td>
				<?php
					echo '<td align="center"><input type="text" name="nome_cliente" value=" '.$nome.'"</td>';
				?>
			</tr>
			<tr>
				<td align="center"> TELEFONE: </td>
				<?php
					echo '<td align="center"><input type="text" name="telefone" value=" '.$telefone.'"</td>';
				?>
			</tr>
			<td align="center"> ENDEREÇO: </td>
			<?php
				echo '<td align="center"><input type="text" name="endereco" value=" '.$endereco.'"</td>';
			?>
			<tr>
				<td align="center"> E-MAIL: </td>
				<?php
					echo '<td align="center"><input type="text" name="email" value=" '.$email.'"</td>';
				?>
			</tr>
			<tr>
				<td align="center"> CPF: </td>
				<?php
					echo '<td align="center"><input type="text" name="cpf" value=" '.$cpf.'"</td>';
				?>
			</tr>
			<tr>
				<td colspan="2" align="center"><input type="submit" name="botao" value="Enviar"></td>
			</tr>
		</table>
	</div>
</form>

<div class="container">
	<h2> Lista Cliente</h2>
		<table class="table table-condensed table-striped table-bordered table-hover">

		<tr>

			<td> ID </td>
			<td> Nome </td>
			<td> Email </td>
			<td> Cpf </td>
			<td> Telefone </td>
			<td> Endereco </td>
			<td> Acao </td>
		</tr>

		<?php
			$query = 'SELECT id_cliente, nome_cliente,email,cpf,telefone,endereco FROM cliente ORDER BY nome_cliente';

			$res = mysql_query($query,$link);
			//echo $res;

			$qtd=mysql_num_rows($res); //numero de linhas
			//echo $qtd;

			if($qtd>0){
				while($linha=mysql_fetch_assoc($res)){
					echo '<tr>';
					echo '<td>'. $linha['id_cliente'].'</td>';
					echo '<td>'. $linha['nome_cliente'].'</td>';
					echo '<td>'. $linha['email'].'</td>';
					echo '<td>'. $linha['cpf'].'</td>';
					echo '<td>'. $linha['telefone'].'</td>';
					echo '<td>'. $linha['endereco'].'</td>';


					echo '<td>
							<a href="index.php?pg=cadastro_cliente&id_cliente='.$linha['id_cliente'].'"> Editar </a> ||
							<a href="acao.cliente.php?acao=delete&id_cliente='.$linha['id_cliente'].'"> Excluir </a>
							</td>';
				}

			}else{

				echo '<tr>
						<td collspan="3" > Nenhum registro para listrar </td>
					</tr>';

			}	
		?>
	</table>
</div>
